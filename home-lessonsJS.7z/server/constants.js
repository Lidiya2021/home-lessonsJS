const GOODS_PATH = './static/goods.json';
const BASKET_GOODS_PATH = './static/basket-goods.json';

module.exports = {
  GOODS_PATH,
  BASKET_GOODS_PATH
}